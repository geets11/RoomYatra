<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Website;
use App\Http\Controllers\Auth;
use App\Http\Controllers\Admin;
use App\Http\Controllers\Dashboard;
use App\Http\Controllers\Landlord;
use App\Http\Controllers\Tenant;
use App\Http\Controllers\Subadmin;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/


Route::get("/", [Website\PathController::class, 'home'])->name('home');
Route::get("/rooms", [Website\PropertyController::class, 'index'])->name('rooms');
Route::get("/how-it-works", [Website\PathController::class, 'howitworks'])->name('howitworks');
Route::get("/contact", [Website\PathController::class, 'contact'])->name('contact');

// Public routes for footer links
Route::get('/rooms', function () {
    return view('public.rooms');
})->name('rooms');

Route::get('/resources', function () {
    return view('public.tenant-resources');
})->name('tenant-resources');

Route::get('/reviews', function () {
    return view('public.tenant-reviews');
})->name('tenant-reviews');

Route::get('/about', function () {
    return view('public.about');
})->name('about');

Route::get('/blog', function () {
    return view('public.blog');
})->name('blog');

Route::get('/privacy', function () {
    return view('public.privacy');
})->name('privacy');

Route::get('/terms', function () {
    return view('public.terms');
})->name('terms');



// Authentication Routes
Route::get('/login', [Auth\LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [Auth\LoginController::class, 'login']);
Route::post('/logout', [Auth\LoginController::class, 'logout'])->name('logout');

// Registration Routes
Route::get('/register', [Auth\RegisterController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [Auth\RegisterController::class, 'register']);

// Password reset routes
Route::get('/password/reset', function () {
    return view('auth.passwords.email');
})->name('password.request');

// Public property routes
Route::get('/properties', [Website\PropertyController::class, 'index'])->name('properties.index');
Route::get('/properties/{property}', [Website\PropertyController::class, 'show'])->name('properties.show');

// Protected routes
Route::middleware(['auth'])->group(function () {
    // Admin routes
    Route::middleware(['role:admin'])->prefix('admin')->name('admin.')->group(function () {
        Route::get('/dashboard', [Dashboard\DashboardController::class, 'admin'])->name('dashboard');

        // User management routes
        Route::resource('users', Admin\UserController::class);

        Route::get('/properties', [Admin\PropertyController::class, 'index'])->name('properties');
        Route::get('/properties/{property}/view', [Admin\PropertyController::class, 'view'])->name('properties.view');
        Route::post('/properties/status', [Admin\PropertyController::class, 'status'])->name('properties.status');


        Route::get('/bookings', function () {
            return view('admin.bookings');
        });
        Route::get('/reports', function () {
            return view('admin.reports');
        });
    });

    // Subadmin routes
    Route::middleware(['role:subadmin'])->prefix('subadmin')->name('subadmin.')->group(function () {
        Route::get('/dashboard', [Dashboard\DashboardController::class, 'subadmin'])->name('dashboard');
        
        // User management routes
        Route::get('/users', [Subadmin\UserController::class, 'index'])->name('users.index');
        Route::get('/users/{user}', [Subadmin\UserController::class, 'show'])->name('users.show');
        Route::get('/users/{user}/edit', [Subadmin\UserController::class, 'edit'])->name('users.edit');
        Route::put('/users/{user}', [Subadmin\UserController::class, 'update'])->name('users.update');
        Route::patch('/users/{user}/toggle-status', [Subadmin\UserController::class, 'toggleStatus'])->name('users.toggle-status');
        
        // Property management routes
        Route::get('/properties', [Subadmin\PropertyController::class, 'index'])->name('properties.index');
        Route::get('/properties/{property}', [Subadmin\PropertyController::class, 'show'])->name('properties.show');
        Route::patch('/properties/{property}/status', [Subadmin\PropertyController::class, 'updateStatus'])->name('properties.update-status');
        Route::patch('/properties/{property}/approve', [Subadmin\PropertyController::class, 'approve'])->name('properties.approve');
        Route::patch('/properties/{property}/reject', [Subadmin\PropertyController::class, 'reject'])->name('properties.reject');
        
        // Booking management routes
        Route::get('/bookings', [Subadmin\BookingController::class, 'index'])->name('bookings.index');
        Route::get('/bookings/{booking}', [Subadmin\BookingController::class, 'show'])->name('bookings.show');
        Route::patch('/bookings/{booking}/status', [Subadmin\BookingController::class, 'updateStatus'])->name('bookings.update-status');
        
        // Support ticket routes
        Route::get('/support', [Subadmin\SupportController::class, 'index'])->name('support.index');
        Route::get('/support/{ticket}', [Subadmin\SupportController::class, 'show'])->name('support.show');
        Route::patch('/support/{ticket}/status', [Subadmin\SupportController::class, 'updateStatus'])->name('support.update-status');
        Route::post('/support/{ticket}/respond', [Subadmin\SupportController::class, 'respond'])->name('support.respond');
    });

    // Landlord routes
    Route::middleware(['role:landlord'])->prefix('landlord')->name('landlord.')->group(function () {
        Route::get('/dashboard', [Dashboard\DashboardController::class, 'landlord'])->name('dashboard');

        // Property management routes
        Route::resource('properties', Landlord\PropertyController::class);
       
        

        // Booking management routes
        Route::get('/bookings', [Landlord\BookingController::class, 'index'])->name('bookings.index');
        Route::get('/bookings/{booking}', [Landlord\BookingController::class, 'show'])->name('bookings.show');
        Route::patch('/bookings/{booking}/status', [Landlord\BookingController::class, 'updateStatus'])->name('bookings.update-status');
        Route::patch('/bookings/{booking}/complete', [Landlord\BookingController::class, 'markCompleted'])->name('bookings.mark-completed');

        // Reviews
        Route::get('/reviews', [App\Http\Controllers\Landlord\ReviewController::class, 'index'])->name('reviews.index');
        Route::get('/reviews/{review}', [App\Http\Controllers\Landlord\ReviewController::class, 'show'])->name('reviews.show');
        Route::post('/reviews/{review}/respond', [App\Http\Controllers\Landlord\ReviewController::class, 'respond'])->name('reviews.respond');
    });

    // Tenant routes
    Route::middleware(['role:tenant'])->prefix('tenant')->name('tenant.')->group(function () {
        Route::get('/dashboard', [Dashboard\DashboardController::class, 'tenant'])->name('dashboard');

        // Booking routes
        Route::get('/bookings', [Tenant\BookingController::class, 'index'])->name('bookings.index');
        Route::get('/bookings/{booking}', [Tenant\BookingController::class, 'show'])->name('bookings.show');
        Route::get('/properties/{property}/book', [Tenant\BookingController::class, 'create'])->name('bookings.create');
        Route::post('/properties/{property}/book', [Tenant\BookingController::class, 'store'])->name('bookings.store');
        Route::patch('/bookings/{booking}/cancel', [Tenant\BookingController::class, 'cancel'])->name('bookings.cancel');


        // Reviews
        Route::get('/reviews', [App\Http\Controllers\Tenant\ReviewController::class, 'index'])->name('reviews.index');
        Route::get('/reviews/create/{booking}', [App\Http\Controllers\Tenant\ReviewController::class, 'create'])->name('reviews.create');
        Route::post('/reviews/store/{booking}', [App\Http\Controllers\Tenant\ReviewController::class, 'store'])->name('reviews.store');
        Route::get('/reviews/{review}', [App\Http\Controllers\Tenant\ReviewController::class, 'show'])->name('reviews.show');
        Route::get('/reviews/{review}/edit', [App\Http\Controllers\Tenant\ReviewController::class, 'edit'])->name('reviews.edit');
        Route::patch('/reviews/{review}', [App\Http\Controllers\Tenant\ReviewController::class, 'update'])->name('reviews.update');
        Route::delete('/reviews/{review}', [App\Http\Controllers\Tenant\ReviewController::class, 'destroy'])->name('reviews.destroy');
    });
});
