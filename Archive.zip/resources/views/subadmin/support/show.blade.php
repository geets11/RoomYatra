@extends('layouts.subadmin.subadmin')

@section('title', 'Support Ticket Details')

@section('content')
<div class="container-fluid">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">Support Ticket #{{ $ticket->id }}</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('subadmin.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('subadmin.support.index') }}">Support Tickets</a></li>
                    <li class="breadcrumb-item active">Ticket #{{ $ticket->id }}</li>
                </ol>
            </nav>
        </div>
        <div>
            <a href="{{ route('subadmin.support.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Tickets
            </a>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="close" data-dismiss="alert">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    @endif

    <div class="row">
        <!-- Ticket Details -->
        <div class="col-lg-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Ticket Information</h6>
                    <div>
                        <span class="badge badge-{{ $ticket->priority === 'urgent' ? 'danger' : ($ticket->priority === 'high' ? 'warning' : ($ticket->priority === 'medium' ? 'info' : 'secondary')) }} mr-2">
                            {{ ucfirst($ticket->priority) }} Priority
                        </span>
                        <span class="badge badge-{{ $ticket->status === 'resolved' ? 'success' : ($ticket->status === 'in_progress' ? 'info' : ($ticket->status === 'open' ? 'warning' : 'secondary')) }}">
                            {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                        </span>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Ticket ID:</strong></td>
                                    <td>#{{ $ticket->id }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Subject:</strong></td>
                                    <td>{{ $ticket->subject }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Priority:</strong></td>
                                    <td>
                                        <span class="badge badge-{{ $ticket->priority === 'urgent' ? 'danger' : ($ticket->priority === 'high' ? 'warning' : ($ticket->priority === 'medium' ? 'info' : 'secondary')) }}">
                                            {{ ucfirst($ticket->priority) }}
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Status:</strong></td>
                                    <td>
                                        <span class="badge badge-{{ $ticket->status === 'resolved' ? 'success' : ($ticket->status === 'in_progress' ? 'info' : ($ticket->status === 'open' ? 'warning' : 'secondary')) }}">
                                            {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                                        </span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Created:</strong></td>
                                    <td>{{ $ticket->created_at->format('M d, Y h:i A') }}</td>
                                </tr>
                                <tr>
                                    <td><strong>Last Updated:</strong></td>
                                    <td>{{ $ticket->updated_at->format('M d, Y h:i A') }}</td>
                                </tr>
                                @if($ticket->resolved_at)
                                    <tr>
                                        <td><strong>Resolved:</strong></td>
                                        <td>{{ $ticket->resolved_at->format('M d, Y h:i A') }}</td>
                                    </tr>
                                @endif
                            </table>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h6 class="font-weight-bold">Original Message</h6>
                        <div class="bg-light p-3 rounded">
                            <p class="mb-0">{{ $ticket->message }}</p>
                        </div>
                    </div>

                    @if($ticket->admin_response)
                        <div class="mb-4">
                            <h6 class="font-weight-bold">Admin Response</h6>
                            <div class="bg-primary text-white p-3 rounded">
                                <p class="mb-0">{{ $ticket->admin_response }}</p>
                            </div>
                        </div>
                    @endif
                </div>
            </div>

            <!-- User Information -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">User Information</h6>
                </div>
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-2">
                            <img src="/placeholder.svg?height=80&width=80&text={{ substr($ticket->user->name, 0, 1) }}" 
                                 alt="{{ $ticket->user->name }}" 
                                 class="rounded-circle">
                        </div>
                        <div class="col-md-6">
                            <h6 class="font-weight-bold">{{ $ticket->user->name }}</h6>
                            <p class="text-muted mb-1">{{ $ticket->user->email }}</p>
                            <p class="text-muted mb-1">{{ $ticket->user->phone ?? 'Phone not provided' }}</p>
                            <small class="text-muted">Member since {{ $ticket->user->created_at->format('M Y') }}</small>
                        </div>
                        <div class="col-md-4">
                            <a href="{{ route('subadmin.users.show', $ticket->user) }}" class="btn btn-outline-primary">
                                <i class="fas fa-user"></i> View Profile
                            </a>
                            <a href="mailto:{{ $ticket->user->email }}" class="btn btn-outline-secondary">
                                <i class="fas fa-envelope"></i> Email User
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Actions Sidebar -->
        <div class="col-lg-4">
            <!-- Status Update -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Update Status</h6>
                </div>
                <div class="card-body">
                    <form action="{{ route('subadmin.support.update-status', $ticket) }}" method="POST">
                        @csrf
                        @method('PATCH')
                        
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control" required>
                                <option value="open" {{ $ticket->status === 'open' ? 'selected' : '' }}>Open</option>
                                <option value="in_progress" {{ $ticket->status === 'in_progress' ? 'selected' : '' }}>In Progress</option>
                                <option value="resolved" {{ $ticket->status === 'resolved' ? 'selected' : '' }}>Resolved</option>
                                <option value="closed" {{ $ticket->status === 'closed' ? 'selected' : '' }}>Closed</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="admin_response">Response</label>
                            <textarea name="admin_response" id="admin_response" class="form-control" rows="4" 
                                      placeholder="Type your response to the user...">{{ $ticket->admin_response }}</textarea>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fas fa-save"></i> Update Ticket
                        </button>
                    </form>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Quick Actions</h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        @if($ticket->status !== 'in_progress')
                            <form action="{{ route('subadmin.support.update-status', $ticket) }}" method="POST" class="mb-2">
                                @csrf
                                @method('PATCH')
                                <input type="hidden" name="status" value="in_progress">
                                <button type="submit" class="btn btn-info btn-block">
                                    <i class="fas fa-play"></i> Start Working
                                </button>
                            </form>
                        @endif

                        @if($ticket->status !== 'resolved')
                            <form action="{{ route('subadmin.support.update-status', $ticket) }}" method="POST" class="mb-2">
                                @csrf
                                @method('PATCH')
                                <input type="hidden" name="status" value="resolved">
                                <button type="submit" class="btn btn-success btn-block">
                                    <i class="fas fa-check"></i> Mark Resolved
                                </button>
                            </form>
                        @endif

                        <a href="mailto:{{ $ticket->user->email }}?subject=Re: {{ $ticket->subject }}" class="btn btn-outline-primary btn-block">
                            <i class="fas fa-envelope"></i> Email User
                        </a>
                    </div>
                </div>
            </div>

            <!-- Ticket Timeline -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Timeline</h6>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        <div class="timeline-item">
                            <div class="timeline-marker bg-primary"></div>
                            <div class="timeline-content">
                                <h6 class="timeline-title">Ticket Created</h6>
                                <p class="timeline-text">{{ $ticket->created_at->format('M d, Y h:i A') }}</p>
                            </div>
                        </div>
                        
                        @if($ticket->status === 'in_progress' || $ticket->status === 'resolved' || $ticket->status === 'closed')
                            <div class="timeline-item">
                                <div class="timeline-marker bg-info"></div>
                                <div class="timeline-content">
                                    <h6 class="timeline-title">In Progress</h6>
                                    <p class="timeline-text">{{ $ticket->updated_at->format('M d, Y h:i A') }}</p>
                                </div>
                            </div>
                        @endif

                        @if($ticket->status === 'resolved' || $ticket->status === 'closed')
                            <div class="timeline-item">
                                <div class="timeline-marker bg-success"></div>
                                <div class="timeline-content">
                                    <h6 class="timeline-title">Resolved</h6>
                                    <p class="timeline-text">{{ $ticket->resolved_at ? $ticket->resolved_at->format('M d, Y h:i A') : 'N/A' }}</p>
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.timeline {
    position: relative;
    padding-left: 30px;
}

.timeline::before {
    content: '';
    position: absolute;
    left: 15px;
    top: 0;
    bottom: 0;
    width: 2px;
    background: #e3e6f0;
}

.timeline-item {
    position: relative;
    margin-bottom: 20px;
}

.timeline-marker {
    position: absolute;
    left: -22px;
    top: 0;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    border: 2px solid #fff;
}

.timeline-content {
    background: #f8f9fc;
    padding: 10px 15px;
    border-radius: 5px;
    border-left: 3px solid #5a5c69;
}

.timeline-title {
    margin: 0 0 5px 0;
    font-size: 14px;
    font-weight: 600;
}

.timeline-text {
    margin: 0;
    font-size: 12px;
    color: #6c757d;
}
</style>
@endsection
