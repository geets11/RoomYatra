<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Subadmin Dashboard - RoomYatra</title>
@vite('resources/css/app.css')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-50">
<!-- Navigation -->
<nav class="bg-white shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex">
                <div class="flex-shrink-0 flex items-center">
                    <a href="/" class="text-xl font-bold text-rose-600">RoomYatra</a>
                </div>
                <div class="hidden sm:ml-6 sm:flex sm:space-x-8">
                    <a href="/subadmin/dashboard" class="border-rose-500 text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                        Dashboard
                    </a>
                    <a href="/subadmin/users" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                        Users
                    </a>
                    <a href="/subadmin/properties" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                        Properties
                    </a>
                    <a href="/subadmin/bookings" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                        Bookings
                    </a>
                    <a href="/subadmin/support" class="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                        Support
                    </a>
                </div>
            </div>
            <div class="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-4">
                <div class="relative">
                    <button type="button" class="flex items-center text-sm font-medium text-gray-700 hover:text-gray-800">
                        <span>{{ Auth::user()->name }}</span>
                        <svg class="ml-1 h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                        </svg>
                    </button>
                </div>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="text-gray-500 hover:text-gray-700 px-3 py-2 text-sm font-medium">
                        Logout
                    </button>
                </form>
            </div>
        </div>
    </div>
</nav>

<!-- Page Header -->
<div class="bg-white shadow">
    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div class="md:flex md:items-center md:justify-between">
            <div class="flex-1 min-w-0">
                <h1 class="text-3xl font-bold text-gray-900">Subadmin Dashboard</h1>
                <p class="mt-1 text-sm text-gray-500">Welcome back, {{ Auth::user()->name }}! Here's what's happening today.</p>
            </div>
            <div class="mt-4 flex md:mt-0 md:ml-4">
                <span class="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    {{ now()->format('M d, Y') }}
                </span>
            </div>
        </div>
    </div>
</div>

<!-- Dashboard Content -->
<div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
    <!-- Stats Overview -->
    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <!-- Users Card -->
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-rose-500 rounded-md p-3">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">
                                Total Users
                            </dt>
                            <dd>
                                <div class="text-lg font-medium text-gray-900">
                                    {{ number_format($totalUsers) }}
                                </div>
                                <div class="text-sm text-green-600">
                                    +{{ $newUsersThisMonth }} this month
                                </div>
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-4 py-4 sm:px-6">
                <div class="text-sm">
                    <a href="/subadmin/users" class="font-medium text-rose-600 hover:text-rose-500">
                        Manage users
                    </a>
                </div>
            </div>
        </div>

        <!-- Properties Card -->
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-blue-500 rounded-md p-3">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">
                                Active Properties
                            </dt>
                            <dd>
                                <div class="text-lg font-medium text-gray-900">
                                    {{ number_format($activeProperties) }}
                                </div>
                                <div class="text-sm text-yellow-600">
                                    {{ $pendingProperties }} pending approval
                                </div>
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-4 py-4 sm:px-6">
                <div class="text-sm">
                    <a href="/subadmin/properties" class="font-medium text-blue-600 hover:text-blue-500">
                        Manage properties
                    </a>
                </div>
            </div>
        </div>

        <!-- Bookings Card -->
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-green-500 rounded-md p-3">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">
                                Total Bookings
                            </dt>
                            <dd>
                                <div class="text-lg font-medium text-gray-900">
                                    {{ number_format($totalBookings) }}
                                </div>
                                <div class="text-sm text-yellow-600">
                                    {{ $pendingBookings }} pending
                                </div>
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-4 py-4 sm:px-6">
                <div class="text-sm">
                    <a href="/subadmin/bookings" class="font-medium text-green-600 hover:text-green-500">
                        Manage bookings
                    </a>
                </div>
            </div>
        </div>

        <!-- Support Tickets Card -->
        <div class="bg-white overflow-hidden shadow rounded-lg">
            <div class="px-4 py-5 sm:p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0 bg-yellow-500 rounded-md p-3">
                        <svg class="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" />
                        </svg>
                    </div>
                    <div class="ml-5 w-0 flex-1">
                        <dl>
                            <dt class="text-sm font-medium text-gray-500 truncate">
                                Open Support Tickets
                            </dt>
                            <dd>
                                <div class="text-lg font-medium text-gray-900">
                                    {{ number_format($openTickets) }}
                                </div>
                                <div class="text-sm text-red-600">
                                    {{ $urgentTickets }} urgent
                                </div>
                            </dd>
                        </dl>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-4 py-4 sm:px-6">
                <div class="text-sm">
                    <a href="/subadmin/support" class="font-medium text-yellow-600 hover:text-yellow-500">
                        View support tickets
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <!-- Monthly Bookings Chart -->
        <div class="bg-white shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:px-6">
                <h3 class="text-lg leading-6 font-medium text-gray-900">Monthly Bookings</h3>
                <p class="mt-1 max-w-2xl text-sm text-gray-500">Booking trends for {{ now()->year }}</p>
            </div>
            <div class="px-4 py-4">
                <canvas id="bookingsChart" width="400" height="200"></canvas>
            </div>
        </div>

        <!-- Monthly Users Chart -->
        <div class="bg-white shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:px-6">
                <h3 class="text-lg leading-6 font-medium text-gray-900">Monthly User Registrations</h3>
                <p class="mt-1 max-w-2xl text-sm text-gray-500">New user registrations for {{ now()->year }}</p>
            </div>
            <div class="px-4 py-4">
                <canvas id="usersChart" width="400" height="200"></canvas>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Recent Support Tickets -->
        <div class="bg-white shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:px-6 flex justify-between items-center">
                <div>
                    <h3 class="text-lg leading-6 font-medium text-gray-900">Recent Support Tickets</h3>
                    <p class="mt-1 max-w-2xl text-sm text-gray-500">Latest support requests</p>
                </div>
                <a href="/subadmin/support" class="text-sm font-medium text-rose-600 hover:text-rose-500">View all</a>
            </div>
            <div class="border-t border-gray-200">
                <ul role="list" class="divide-y divide-gray-200">
                    @forelse($recentTickets as $ticket)
                    <li class="px-4 py-4 sm:px-6">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                    <span class="text-gray-500 font-medium text-xs">
                                        {{ strtoupper(substr($ticket->user->name, 0, 2)) }}
                                    </span>
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900">{{ $ticket->subject }}</div>
                                    <div class="text-sm text-gray-500">{{ $ticket->user->name }} - {{ ucfirst($ticket->user->role) }}</div>
                                    <div class="text-xs text-gray-400">{{ $ticket->created_at->diffForHumans() }}</div>
                                </div>
                            </div>
                            <div class="flex flex-col items-end">
                                <span class="text-sm text-{{ $ticket->status_color }}-500 font-medium">
                                    {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                                </span>
                                @if($ticket->priority === 'urgent')
                                <span class="text-xs text-red-500 font-medium">{{ ucfirst($ticket->priority) }}</span>
                                @endif
                            </div>
                        </div>
                    </li>
                    @empty
                    <li class="px-4 py-4 sm:px-6 text-center text-gray-500">
                        No support tickets found
                    </li>
                    @endforelse
                </ul>
            </div>
        </div>

        <!-- Recent Bookings -->
        <div class="bg-white shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:px-6 flex justify-between items-center">
                <div>
                    <h3 class="text-lg leading-6 font-medium text-gray-900">Recent Bookings</h3>
                    <p class="mt-1 max-w-2xl text-sm text-gray-500">Latest property bookings</p>
                </div>
                <a href="/subadmin/bookings" class="text-sm font-medium text-rose-600 hover:text-rose-500">View all</a>
            </div>
            <div class="border-t border-gray-200">
                <ul role="list" class="divide-y divide-gray-200">
                    @forelse($recentBookings as $booking)
                    <li class="px-4 py-4 sm:px-6">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10 rounded bg-gray-200 flex items-center justify-center overflow-hidden">
                                    @if($booking->property->images->count() > 0)
                                        <img src="{{ $booking->property->images->first()->image_path }}" alt="Property" class="h-full w-full object-cover">
                                    @else
                                        <img src="/placeholder.svg?height=40&width=40" alt="Property" class="h-full w-full object-cover">
                                    @endif
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900">{{ $booking->property->title ?? 'Property' }}</div>
                                    <div class="text-sm text-gray-500">{{ $booking->user->name }} - {{ $booking->created_at->format('M d, Y') }}</div>
                                    <div class="text-xs text-gray-400">{{ $booking->property->propertyType->name ?? 'Property' }}</div>
                                </div>
                            </div>
                            <div class="text-sm font-medium">
                                @if($booking->status === 'approved')
                                    <span class="text-green-500">Confirmed</span>
                                @elseif($booking->status === 'pending')
                                    <span class="text-yellow-500">Pending</span>
                                @elseif($booking->status === 'cancelled')
                                    <span class="text-red-500">Cancelled</span>
                                @else
                                    <span class="text-gray-500">{{ ucfirst($booking->status) }}</span>
                                @endif
                            </div>
                        </div>
                    </li>
                    @empty
                    <li class="px-4 py-4 sm:px-6 text-center text-gray-500">
                        No bookings found
                    </li>
                    @endforelse
                </ul>
            </div>
        </div>

        <!-- Recent Users -->
        <div class="bg-white shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:px-6 flex justify-between items-center">
                <div>
                    <h3 class="text-lg leading-6 font-medium text-gray-900">Recent Users</h3>
                    <p class="mt-1 max-w-2xl text-sm text-gray-500">Latest user registrations</p>
                </div>
                <a href="/subadmin/users" class="text-sm font-medium text-rose-600 hover:text-rose-500">View all</a>
            </div>
            <div class="border-t border-gray-200">
                <ul role="list" class="divide-y divide-gray-200">
                    @forelse($recentUsers as $user)
                    <li class="px-4 py-4 sm:px-6">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <div class="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                    @if($user->profile_photo)
                                        <img src="{{ $user->profile_photo }}" alt="{{ $user->name }}" class="h-full w-full rounded-full object-cover">
                                    @else
                                        <span class="text-gray-500 font-medium text-sm">
                                            {{ strtoupper(substr($user->name, 0, 2)) }}
                                        </span>
                                    @endif
                                </div>
                                <div class="ml-4">
                                    <div class="text-sm font-medium text-gray-900">{{ $user->name }}</div>
                                    <div class="text-sm text-gray-500">{{ $user->email }}</div>
                                    <div class="text-xs text-gray-400">{{ $user->created_at->diffForHumans() }}</div>
                                </div>
                            </div>
                            <div class="text-sm font-medium">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                                    {{ $user->role === 'landlord' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800' }}">
                                    {{ ucfirst($user->role) }}
                                </span>
                            </div>
                        </div>
                    </li>
                    @empty
                    <li class="px-4 py-4 sm:px-6 text-center text-gray-500">
                        No users found
                    </li>
                    @endforelse
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="bg-gray-800 mt-12">
    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <p class="text-center text-base text-gray-400">
            &copy; 2025 RoomYatra, Inc. All rights reserved.
        </p>
    </div>
</footer>

<script>
// Monthly Bookings Chart
const bookingsCtx = document.getElementById('bookingsChart').getContext('2d');
const bookingsData = @json($monthlyBookings);
const bookingsChart = new Chart(bookingsCtx, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
            label: 'Bookings',
            data: [
                bookingsData[1] || 0, bookingsData[2] || 0, bookingsData[3] || 0,
                bookingsData[4] || 0, bookingsData[5] || 0, bookingsData[6] || 0,
                bookingsData[7] || 0, bookingsData[8] || 0, bookingsData[9] || 0,
                bookingsData[10] || 0, bookingsData[11] || 0, bookingsData[12] || 0
            ],
            borderColor: 'rgb(34, 197, 94)',
            backgroundColor: 'rgba(34, 197, 94, 0.1)',
            tension: 0.1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Monthly Users Chart
const usersCtx = document.getElementById('usersChart').getContext('2d');
const usersData = @json($monthlyUsers);
const usersChart = new Chart(usersCtx, {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [{
            label: 'New Users',
            data: [
                usersData[1] || 0, usersData[2] || 0, usersData[3] || 0,
                usersData[4] || 0, usersData[5] || 0, usersData[6] || 0,
                usersData[7] || 0, usersData[8] || 0, usersData[9] || 0,
                usersData[10] || 0, usersData[11] || 0, usersData[12] || 0
            ],
            backgroundColor: 'rgba(244, 63, 94, 0.8)',
            borderColor: 'rgb(244, 63, 94)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>
</body>
</html>
