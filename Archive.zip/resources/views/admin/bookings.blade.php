{{-- resources/views/admin/bookings.blade.php --}}

@extends('layouts.app') {{-- Adjust if your layout file is different --}}

@section('content')
    <div class="container">
        <h1>Admin Bookings Page</h1>
        <p>This is the bookings page for admin panel.</p>
    </div>
@endsection
