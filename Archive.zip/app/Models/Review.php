<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Review extends Model
{
    use HasFactory;

    protected $fillable = [
        'booking_id',
        'user_id',
        'property_id',
        'rating',
        'cleanliness_rating',
        'communication_rating',
        'check_in_rating',
        'accuracy_rating',
        'location_rating',
        'value_rating',
        'comment',
        'landlord_response',
        'is_published',
    ];

    protected $casts = [
        'rating' => 'float',
        'cleanliness_rating' => 'integer',
        'communication_rating' => 'integer',
        'check_in_rating' => 'integer',
        'accuracy_rating' => 'integer',
        'location_rating' => 'integer',
        'value_rating' => 'integer',
        'is_published' => 'boolean',
    ];

    public function booking()
    {
        return $this->belongsTo(Booking::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function property()
    {
        return $this->belongsTo(Property::class);
    }
}
