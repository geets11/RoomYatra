<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Property extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'property_type_id',
        'title',
        'slug',
        'description',
        'price',
        'price_type',
        'address',
        'city',
        'state',
        'zip_code',
        'country',
        'latitude',
        'longitude',
        'bedrooms',
        'bathrooms',
        'size',
        'is_furnished',
        'is_approved',
        'is_featured',
        'is_available',
        'available_from',
        'available_to',
        'status',
    ];

    protected $casts = [
        'is_furnished' => 'boolean',
        'is_approved' => 'boolean',
        'is_featured' => 'boolean',
        'is_available' => 'boolean',
        'available_from' => 'date',
        'available_to' => 'date',
    ];

    /**
     * Get the user that owns the property.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the property type that owns the property.
     */
    public function propertyType()
    {
        return $this->belongsTo(PropertyType::class);
    }

    /**
     * Get the images for the property.
     */
    public function images()
    {
        return $this->hasMany(PropertyImage::class);
    }

    /**
     * Get the primary image for the property.
     */
    public function primaryImage()
    {
        return $this->hasOne(PropertyImage::class)->where('is_primary', true);
    }

    /**
     * Get the amenities for the property.
     */
    public function amenities()
    {
        return $this->belongsToMany(Amenity::class, 'property_amenities');
    }

    /**
     * Scope a query to only include available properties.
     */
    public function scopeAvailable($query)
    {
        return $query->where('is_available', true);
    }

    /**
     * Scope a query to only include approved properties.
     */
    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    /**
     * Scope a query to only include featured properties.
     */
    public function scopeFeatured($query)
    {
        return $query->where('is_featured', true);
    }

    /**
     * Get the bookings for the property.
     */
    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    /**
     * Get the reviews for the property.
     */
    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    /**
     * Get the average rating for the property.
     */
    public function getAverageRatingAttribute()
    {
        return $this->reviews()->where('is_approved', true)->avg('rating') ?: 0;
    }

    /**
     * Get the number of reviews for the property.
     */
    public function getReviewsCountAttribute()
    {
        return $this->reviews()->where('is_approved', true)->count();
    }

    /**
     * Check if the property is available for the given dates.
     */
    public function isAvailable($checkIn, $checkOut)
    {
        $checkIn = is_string($checkIn) ? new \DateTime($checkIn) : $checkIn;
        $checkOut = is_string($checkOut) ? new \DateTime($checkOut) : $checkOut;

        // Check if there are any overlapping bookings
        $overlappingBookings = $this->bookings()
            ->where('status', '!=', 'cancelled')
            ->where('status', '!=', 'rejected')
            ->where(function ($query) use ($checkIn, $checkOut) {
                $query->where(function ($q) use ($checkIn, $checkOut) {
                    // Check if the new booking's check-in date falls within an existing booking
                    $q->where('check_in', '<=', $checkIn)
                        ->where('check_out', '>', $checkIn);
                })->orWhere(function ($q) use ($checkIn, $checkOut) {
                    // Check if the new booking's check-out date falls within an existing booking
                    $q->where('check_in', '<', $checkOut)
                        ->where('check_out', '>=', $checkOut);
                })->orWhere(function ($q) use ($checkIn, $checkOut) {
                    // Check if the new booking completely contains an existing booking
                    $q->where('check_in', '>=', $checkIn)
                        ->where('check_out', '<=', $checkOut);
                });
            })
            ->count();

        return $overlappingBookings === 0;
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
