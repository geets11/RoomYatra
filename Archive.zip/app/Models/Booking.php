<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'property_id',
        'user_id',
        'check_in',
        'check_out',
        'guests',
        'total_price',
        'special_requests',
        'status',
        'rejection_reason',
        'is_paid',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'check_in' => 'date',
        'check_out' => 'date',
        'total_price' => 'float',
        'guests' => 'integer',
        'is_paid' => 'boolean',
    ];

    /**
     * Get the property that was booked.
     */
    public function property()
    {
        return $this->belongsTo(Property::class);
    }

    /**
     * Get the user (tenant) who made the booking.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the review associated with the booking.
     */
    public function review()
    {
        return $this->hasOne(Review::class);
    }

    /**
     * Check if the booking can be reviewed.
     */
    public function canBeReviewed()
    {
        return $this->status === 'completed' && !$this->review()->exists();
    }

    /**
     * Calculate the number of nights.
     */
    public function getNightsAttribute()
    {
        return $this->check_in->diffInDays($this->check_out);
    }
}
