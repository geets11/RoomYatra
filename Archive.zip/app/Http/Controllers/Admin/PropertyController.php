<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Property;
use Illuminate\Http\Request;

class PropertyController extends Controller
{
    public function index()
    {
        $properties = Property::with(['propertyType', 'createdBy'])
            ->get();
        return view('admin.properties.index', compact('properties'));
    }

    public function view(Property $property)
    {
        $property->load('propertyType', 'images', 'amenities', 'createdBy');
        return view('admin.properties.view', compact('property'));
    }

    public function status()
    {
        // dd(request()->all());
        $property_id = request()->id;
        $property = Property::find($property_id);
        $property->status = request()->status;
        if ($property->save()) {
            return response()->json(['status' => true]);
        } else {
            return response()->json(['status' => false]);
        }
    }
}
