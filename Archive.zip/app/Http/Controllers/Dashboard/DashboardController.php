<?php

namespace App\Http\Controllers\Dashboard;
use App\Http\Controllers\Controller;

use App\Models\Booking;
use App\Models\Property;
use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    /**
     * Show the admin dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function admin()
    {
        return view('dashboard.admin');
    }

    /**
     * Show the subadmin dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function subadmin()
    {
        // Get user statistics
        $totalUsers = \App\Models\User::count();
        $activeUsers = \App\Models\User::whereNotNull('email_verified_at')->count();
        $newUsersThisMonth = \App\Models\User::whereMonth('created_at', now()->month)
            ->whereYear('created_at', now()->year)
            ->count();

        // Get property statistics
        $totalProperties = \App\Models\Property::count();
        $activeProperties = \App\Models\Property::where('status', 'approved')->count();
        $pendingProperties = \App\Models\Property::where('status', 'pending')->count();

        // Get booking statistics
        $totalBookings = \App\Models\Booking::count();
        $pendingBookings = \App\Models\Booking::where('status', 'pending')->count();
        $confirmedBookings = \App\Models\Booking::where('status', 'approved')->count();

        // Get support ticket statistics
        $totalTickets = \App\Models\SupportTicket::count();
        $openTickets = \App\Models\SupportTicket::whereIn('status', ['open', 'in_progress'])->count();
        $urgentTickets = \App\Models\SupportTicket::where('priority', 'urgent')->count();

        // Get recent support tickets
        $recentTickets = \App\Models\SupportTicket::with(['user'])
            ->latest()
            ->take(5)
            ->get();

        // Get recent bookings
        $recentBookings = \App\Models\Booking::with(['property', 'property.images', 'property.propertyType', 'user'])
            ->latest()
            ->take(5)
            ->get();

        // Get recent users
        $recentUsers = \App\Models\User::whereIn('role', ['tenant', 'landlord'])
            ->latest()
            ->take(5)
            ->get();

        // Get monthly statistics for charts
        $monthlyBookings = \App\Models\Booking::selectRaw('MONTH(created_at) as month, COUNT(*) as count')
            ->whereYear('created_at', now()->year)
            ->groupBy('month')
            ->pluck('count', 'month')
            ->toArray();

        $monthlyUsers = \App\Models\User::selectRaw('MONTH(created_at) as month, COUNT(*) as count')
            ->whereYear('created_at', now()->year)
            ->groupBy('month')
            ->pluck('count', 'month')
            ->toArray();

        return view('dashboard.subadmin', compact(
            'totalUsers',
            'activeUsers',
            'newUsersThisMonth',
            'totalProperties',
            'activeProperties',
            'pendingProperties',
            'totalBookings',
            'pendingBookings',
            'confirmedBookings',
            'totalTickets',
            'openTickets',
            'urgentTickets',
            'recentTickets',
            'recentBookings',
            'recentUsers',
            'monthlyBookings',
            'monthlyUsers'
        ));
    }

    /**
     * Show the landlord dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function landlord()
    {
        // dd('here');
        $userId = Auth::id();

        // Get property statistics
        $totalProperties = Property::where('user_id', $userId)->count();
        $activeProperties = Property::where('user_id', $userId)
            ->where('status', 'approved')
            ->count();

        // Get booking statistics
        $pendingBookings = Booking::whereHas('property', function ($query) use ($userId) {
                $query->where('user_id', $userId);
            })
            ->where('status', 'pending')
            ->count();

        $totalBookings = Booking::whereHas('property', function ($query) use ($userId) {
                $query->where('user_id', $userId);
            })
            ->count();

        $completedBookings = Booking::whereHas('property', function ($query) use ($userId) {
                $query->where('user_id', $userId);
            })
            ->where('status', 'completed')
            ->count();

        // Get review statistics
        $totalReviews = Review::whereHas('property', function ($query) use ($userId) {
                $query->where('user_id', $userId);
            })
            ->count();

        // Get recent properties
        $recentProperties = Property::where('user_id', $userId)
            ->with(['propertyType', 'images'])
            ->latest()
            ->take(3)
            ->get();

        // Get recent bookings
        $recentBookings = Booking::whereHas('property', function ($query) use ($userId) {
                $query->where('user_id', $userId);
            })
            ->with(['property', 'property.images', 'user'])
            ->latest()
            ->take(3)
            ->get();

        // For now, we'll set this to 0 since we haven't implemented messages yet
        $unreadMessages = 0;

        return view('dashboard.landlord', compact(
            'totalProperties',
            'activeProperties',
            'pendingBookings',
            'totalBookings',
            'completedBookings',
            'totalReviews',
            'recentProperties',
            'recentBookings',
            'unreadMessages'
        ));
    }

    /**
     * Show the tenant dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function tenant()
    {
        $userId = Auth::id();

        // Get booking statistics
        $totalBookings = Booking::where('user_id', $userId)->count();
        $pendingBookings = Booking::where('user_id', $userId)
            ->where('status', 'pending')
            ->count();
        $upcomingBookings = Booking::where('user_id', $userId)
            ->where('status', 'approved')
            ->where('check_in', '>=', now())
            ->count();

        // Get recent bookings
        $recentBookings = Booking::where('user_id', $userId)
            ->with(['property', 'property.images', 'property.propertyType'])
            ->latest()
            ->take(3)
            ->get();

        // Get review statistics
        $totalReviews = Review::where('user_id', $userId)->count();

        // For now, we'll set this to 0 since we haven't implemented messages yet
        $unreadMessages = 0;

        return view('dashboard.tenant', compact(
            'totalBookings',
            'pendingBookings',
            'upcomingBookings',
            'recentBookings',
            'totalReviews',
            'unreadMessages'
        ));
    }
}
