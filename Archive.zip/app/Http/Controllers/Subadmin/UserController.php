<?php

namespace App\Http\Controllers\Subadmin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'role:subadmin']);
    }

    /**
     * Display a listing of the users.
     */
    public function index(Request $request)
    {
        $query = User::query();

        // Search functionality
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        // Role filter
        if ($request->filled('role')) {
            $query->role($request->role);
        }

        // Status filter
        if ($request->filled('status')) {
            if ($request->status === 'active') {
                $query->whereNull('deleted_at');
            } elseif ($request->status === 'inactive') {
                $query->whereNotNull('deleted_at');
            }
        }

        // Date filter
        if ($request->filled('date_range')) {
            switch ($request->date_range) {
                case 'today':
                    $query->whereDate('created_at', today());
                    break;
                case 'week':
                    $query->whereBetween('created_at', [now()->startOfWeek(), now()->endOfWeek()]);
                    break;
                case 'month':
                    $query->whereMonth('created_at', now()->month);
                    break;
                case 'year':
                    $query->whereYear('created_at', now()->year);
                    break;
            }
        }

        $users = $query->with('roles')->orderBy('created_at', 'desc')->paginate(15);

        // Get statistics
        $stats = [
            'total' => User::count(),
            'tenants' => User::role('tenant')->count(),
            'landlords' => User::role('landlord')->count(),
            'admins' => User::role(['admin', 'subadmin'])->count(),
            'new_this_month' => User::whereMonth('created_at', now()->month)->count(),
        ];

        // Get roles for filter
        $roles = Role::all();

        return view('subadmin.users.index', compact('users', 'stats', 'roles'));
    }

    /**
     * Display the specified user.
     */
    public function show(User $user)
    {
        $user->load(['roles', 'properties', 'bookings.property']);

        return view('subadmin.users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified user.
     */
    public function edit(User $user)
    {
        $roles = Role::all();
        return view('subadmin.users.edit', compact('user', 'roles'));
    }

    /**
     * Update the specified user in storage.
     */
    public function update(Request $request, User $user)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'phone' => 'nullable|string|max:20',
            'role' => 'required|exists:roles,name',
        ]);

        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'phone' => $request->phone,
        ]);

        // Update role
        $user->syncRoles([$request->role]);

        return redirect()->route('subadmin.users.show', $user)
                        ->with('success', 'User updated successfully.');
    }

    /**
     * Toggle user status (activate/deactivate).
     */
    public function toggleStatus(User $user)
    {
        if ($user->deleted_at) {
            $user->restore();
            $message = 'User activated successfully.';
        } else {
            $user->delete();
            $message = 'User deactivated successfully.';
        }

        return redirect()->back()->with('success', $message);
    }

    /**
     * Get user statistics for dashboard.
     */
    public function getStats()
    {
        return [
            'total_users' => User::count(),
            'new_users_today' => User::whereDate('created_at', today())->count(),
            'tenants' => User::role('tenant')->count(),
            'landlords' => User::role('landlord')->count(),
            'recent_users' => User::with('roles')->latest()->take(5)->get(),
        ];
    }
}
