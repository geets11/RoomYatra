<?php

namespace App\Http\Controllers\Landlord;

use App\Http\Controllers\Controller;
use App\Models\Amenity;
use App\Models\Property;
use App\Models\PropertyImage;
use App\Models\PropertyType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class PropertyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $properties = Property::where('user_id', Auth::id())
            ->with(['propertyType', 'images'])
            ->latest()
            ->get();

        return view('landlord.properties.index', compact('properties'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $propertyTypes = PropertyType::all();
        $amenities = Amenity::all();

        return view('landlord.properties.create', compact('propertyTypes', 'amenities'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'property_type_id' => 'required|exists:property_types,id',
            'description' => 'required|string',
            'price' => 'required|numeric|min:0',
            'price_type' => 'required|in:daily,weekly,monthly',
            'size' => 'nullable|numeric|min:0',
            'address' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'state' => 'required|string|max:255',
            'zip_code' => 'required|string|max:20',
            'country' => 'required|string|max:255',
            'bedrooms' => 'required|integer|min:0',
            'bathrooms' => 'required|numeric|min:0',
            'is_furnished' => 'nullable|boolean',
            'available_from' => 'nullable|date',
            'available_to' => 'nullable|date|after_or_equal:available_from',
            'amenities' => 'nullable|array',
            'amenities.*' => 'exists:amenities,id',
            'images' => 'nullable|array',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:100024000',
        ]);

        // Create property
        $property = new Property();
        $property->user_id = Auth::id();
        $property->title = $request->title;
        $property->property_type_id = $request->property_type_id;
        $property->description = $request->description;
        $property->price = $request->price;
        $property->price_type = $request->price_type;
        $property->size = $request->size;
        $property->address = $request->address;
        $property->city = $request->city;
        $property->state = $request->state;
        $property->zip_code = $request->zip_code;
        $property->country = $request->country;
        $property->bedrooms = $request->bedrooms;
        $property->bathrooms = $request->bathrooms;
        $property->is_furnished = $request->has('is_furnished');
        $property->available_from = $request->available_from;
        $property->available_to = $request->available_to;
        $property->status = 'pending'; // Default status is pending
        $property->slug = Str::slug($request->title);
        $property->save();

        // Attach amenities
        if ($request->has('amenities')) {
            $property->amenities()->attach($request->amenities);
        }

        // Handle images
        if ($request->hasFile('images')) {
            $images = $request->file('images');
            foreach ($images as $index => $image) {
                $path = $image->store('property-images', 'public');

                $propertyImage = new PropertyImage();
                $propertyImage->property_id = $property->id;
                $propertyImage->image_path = $path;
                $propertyImage->is_primary = ($index === 0); // First image is primary
                $propertyImage->save();
            }
        }

        return redirect()->route('landlord.properties.index')
            ->with('success', 'Property created successfully. It will be reviewed by an admin before being listed.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Property  $property
     * @return \Illuminate\Http\Response
     */
    public function show(Property $property)
    {
        // Check if the property belongs to the authenticated user
        if ($property->user_id !== Auth::id()) {
            return redirect()->route('landlord.properties.index')
                ->with('error', 'You do not have permission to view this property.');
        }

        $property->load(['propertyType', 'amenities', 'images']);

        return view('landlord.properties.show', compact('property'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Property  $property
     * @return \Illuminate\Http\Response
     */
    public function edit(Property $property)
    {
        // Check if the property belongs to the authenticated user
        if ($property->user_id !== Auth::id()) {
            return redirect()->route('landlord.properties.index')
                ->with('error', 'You do not have permission to edit this property.');
        }

        $propertyTypes = PropertyType::all();
        $amenities = Amenity::all();
        $property->load(['propertyType', 'amenities', 'images']);

        return view('landlord.properties.edit', compact('property', 'propertyTypes', 'amenities'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Property  $property
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Property $property)
    {
        // Check if the property belongs to the authenticated user
        if ($property->user_id !== Auth::id()) {
            return redirect()->route('landlord.properties.index')
                ->with('error', 'You do not have permission to update this property.');
        }

        $request->validate([
            'title' => 'required|string|max:255',
            'property_type_id' => 'required|exists:property_types,id',
            'description' => 'required|string',
            'price' => 'required|numeric|min:0',
            'price_type' => 'required|in:daily,weekly,monthly',
            'size' => 'nullable|numeric|min:0',
            'address' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'state' => 'required|string|max:255',
            'zip_code' => 'required|string|max:20',
            'country' => 'required|string|max:255',
            'bedrooms' => 'required|integer|min:0',
            'bathrooms' => 'required|numeric|min:0',
            'is_furnished' => 'nullable|boolean',
            'available_from' => 'nullable|date',
            'available_to' => 'nullable|date|after_or_equal:available_from',
            'amenities' => 'nullable|array',
            'amenities.*' => 'exists:amenities,id',
            'new_images' => 'nullable|array',
            'new_images.*' => 'image|mimes:jpeg,png,jpg,gif|max:10240',
            'delete_images' => 'nullable|array',
            'delete_images.*' => 'exists:property_images,id',
            'primary_image' => 'nullable|exists:property_images,id',
        ]);

        // Update property
        $property->title = $request->title;
        $property->property_type_id = $request->property_type_id;
        $property->description = $request->description;
        $property->price = $request->price;
        $property->price_type = $request->price_type;
        $property->size = $request->size;
        $property->address = $request->address;
        $property->city = $request->city;
        $property->state = $request->state;
        $property->zip_code = $request->zip_code;
        $property->country = $request->country;
        $property->bedrooms = $request->bedrooms;
        $property->bathrooms = $request->bathrooms;
        $property->is_furnished = $request->has('is_furnished');
        $property->available_from = $request->available_from;
        $property->available_to = $request->available_to;

        // If the property was approved and we're making significant changes, set it back to pending
        if (
            $property->status === 'approved' &&
            ($property->isDirty('title') ||
                $property->isDirty('description') ||
                $property->isDirty('price') ||
                $property->isDirty('bedrooms') ||
                $property->isDirty('bathrooms') ||
                $property->isDirty('address'))
        ) {
            $property->status = 'pending';
        }

        $property->save();

        // Sync amenities
        if ($request->has('amenities')) {
            $property->amenities()->sync($request->amenities);
        } else {
            $property->amenities()->detach();
        }

        // Handle image deletion
        if ($request->has('delete_images')) {
            $imagesToDelete = PropertyImage::where('property_id', $property->id)
                ->whereIn('id', $request->delete_images)
                ->get();

            foreach ($imagesToDelete as $image) {
                // Delete the file from storage
                if (Storage::disk('public')->exists($image->image_path)) {
                    Storage::disk('public')->delete($image->image_path);
                }

                // Delete the database record
                $image->delete();
            }
        }

        // Set primary image
        if ($request->has('primary_image')) {
            // Reset all images to non-primary
            PropertyImage::where('property_id', $property->id)
                ->update(['is_primary' => false]);

            // Set the selected image as primary
            PropertyImage::where('id', $request->primary_image)
                ->update(['is_primary' => true]);
        }

        // Handle new images
        if ($request->hasFile('new_images')) {
            $images = $request->file('new_images');
            $hasPrimary = PropertyImage::where('property_id', $property->id)
                ->where('is_primary', true)
                ->exists();

            foreach ($images as $index => $image) {
                $path = $image->store('property-images', 'public');

                $propertyImage = new PropertyImage();
                $propertyImage->property_id = $property->id;
                $propertyImage->image_path = $path;
                $propertyImage->is_primary = (!$hasPrimary && $index === 0); // First image is primary if no primary exists
                $propertyImage->save();

                if (!$hasPrimary && $index === 0) {
                    $hasPrimary = true;
                }
            }
        }

        return redirect()->route('landlord.properties.show', $property)
            ->with('success', 'Property updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Property  $property
     * @return \Illuminate\Http\Response
     */
    public function destroy(Property $property)
    {
        // Check if the property belongs to the authenticated user
        if ($property->user_id !== Auth::id()) {
            return redirect()->route('landlord.properties.index')
                ->with('error', 'You do not have permission to delete this property.');
        }

        // Delete property images from storage
        foreach ($property->images as $image) {
            if (Storage::disk('public')->exists($image->image_path)) {
                Storage::disk('public')->delete($image->image_path);
            }
        }

        // Delete the property (this will cascade delete related records)
        $property->delete();

        return redirect()->route('landlord.properties.index')
            ->with('success', 'Property deleted successfully.');
    }
}
