<?php

namespace App\Http\Controllers\Landlord;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{
    public function index()
    {
        // Get all properties owned by the landlord
        $propertyIds = Property::where('user_id', Auth::id())->pluck('id');

        // Get all bookings for those properties
        $bookings = Booking::with(['property', 'property.images', 'user'])
            ->whereIn('property_id', $propertyIds)
            ->orderBy('created_at', 'desc')
            ->get();

        // Get counts for different booking statuses
        $pendingCount = $bookings->where('status', 'pending')->count();
        $approvedCount = $bookings->where('status', 'approved')->count();
        $completedCount = $bookings->where('status', 'completed')->count();
        $cancelledCount = $bookings->where('status', 'cancelled')->count();
        $rejectedCount = $bookings->where('status', 'rejected')->count();

        return view('landlord.bookings.index', compact('bookings', 'pendingCount', 'approvedCount', 'completedCount', 'cancelledCount', 'rejectedCount'));
    }

    public function show(Booking $booking)
    {
        // Check if the booking is for a property owned by the landlord
        $propertyIds = Property::where('user_id', Auth::id())->pluck('id');

        if (!$propertyIds->contains($booking->property_id)) {
            abort(403, 'Unauthorized action.');
        }

        $booking->load(['property', 'property.images', 'property.amenities', 'user']);

        return view('landlord.bookings.show', compact('booking'));
    }

    public function updateStatus(Request $request, Booking $booking)
    {
        // Check if the booking is for a property owned by the landlord
        $propertyIds = Property::where('user_id', Auth::id())->pluck('id');

        if (!$propertyIds->contains($booking->property_id)) {
            abort(403, 'Unauthorized action.');
        }

        // Validate the request
        $validated = $request->validate([
            'status' => 'required|in:approved,rejected',
            'message' => 'nullable|string|max:500',
        ]);

        // Check if the booking can be updated
        if ($booking->status !== 'pending') {
            return back()->withErrors(['message' => 'This booking cannot be updated.']);
        }

        // Check for conflicting bookings if approving
        if ($validated['status'] === 'approved') {
            $conflictingBookings = Booking::where('property_id', $booking->property_id)
                ->where('id', '!=', $booking->id)
                ->where('status', 'approved')
                ->where(function($query) use ($booking) {
                    $query->whereBetween('check_in', [$booking->check_in, $booking->check_out])
                        
                        ->orWhere(function($q) use ($booking) {
                            $q->where('check_in', '<=', $booking->check_in);
                        });
                })
                ->exists();

            if ($conflictingBookings) {
                return back()->withErrors(['message' => 'There is a conflicting booking for these dates.']);
            }
        }

        // Update the booking
        $booking->status = $validated['status'];
        $booking->landlord_message = $validated['message'];
        $booking->save();

        $statusText = $validated['status'] === 'approved' ? 'approved' : 'rejected';

        return redirect()->route('landlord.bookings.show', $booking->id)
            ->with('success', "Booking {$statusText} successfully.");
    }

    public function markCompleted(Request $request, Booking $booking)
    {
        // Check if the booking is for a property owned by the landlord
        $propertyIds = Property::where('user_id', Auth::id())->pluck('id');

        if (!$propertyIds->contains($booking->property_id)) {
            abort(403, 'Unauthorized action.');
        }

        // Check if the booking can be marked as completed
        if ($booking->status !== 'approved') {
            return back()->withErrors(['message' => 'This booking cannot be marked as completed.']);
        }

        // Check if the check-out date has passed
        if (now()->lt($booking->check_out)) {
            return back()->withErrors(['message' => 'This booking cannot be marked as completed until the check-out date has passed.']);
        }

        // Update the booking
        $booking->status = 'completed';
        $booking->save();

        return redirect()->route('landlord.bookings.show', $booking->id)
            ->with('success', 'Booking marked as completed successfully.');
    }
}
