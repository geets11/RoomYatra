<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Property;
use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ReviewController extends Controller
{
    public function index()
    {
        $reviews = Review::where('user_id', Auth::id())
            ->with(['property', 'booking'])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('tenant.reviews.index', compact('reviews'));
    }

    public function create(Booking $booking)
    {
        // Check if the booking belongs to the tenant
        if ($booking->user_id !== Auth::id()) {
            abort(403, 'Unauthorized action.');
        }

        // Check if the booking is completed
        if ($booking->status !== 'completed') {
            return redirect()->route('tenant.bookings.show', $booking->id)
                ->with('error', 'You can only review completed bookings.');
        }

        // Check if a review already exists
        $existingReview = Review::where('booking_id', $booking->id)
            ->where('user_id', Auth::id())
            ->first();

        if ($existingReview) {
            return redirect()->route('tenant.reviews.edit', $existingReview->id)
                ->with('info', 'You have already reviewed this booking. You can edit your review.');
        }

        return view('tenant.reviews.create', compact('booking'));
    }

    public function store(Request $request, Booking $booking)
    {
        // Check if the booking belongs to the tenant
        if ($booking->user_id !== Auth::id()) {
            abort(403, 'Unauthorized action.');
        }

        // Validate the request
        $validated = $request->validate([
            'cleanliness_rating' => 'required|integer|min:1|max:5',
            'communication_rating' => 'required|integer|min:1|max:5',
            'check_in_rating' => 'required|integer|min:1|max:5',
            'accuracy_rating' => 'required|integer|min:1|max:5',
            'location_rating' => 'required|integer|min:1|max:5',
            'value_rating' => 'required|integer|min:1|max:5',
            'comment' => 'required|string|min:10|max:1000',
        ]);

        // Calculate the overall rating (average of all ratings)
        $overallRating = round(
            ($validated['cleanliness_rating'] +
            $validated['communication_rating'] +
            $validated['check_in_rating'] +
            $validated['accuracy_rating'] +
            $validated['location_rating'] +
            $validated['value_rating']) / 6,
            1
        );

        // Create the review
        $review = new Review();
        $review->booking_id = $booking->id;
        $review->user_id = Auth::id();
        $review->property_id = $booking->property_id;
        $review->rating = $overallRating;
        $review->cleanliness_rating = $validated['cleanliness_rating'];
        $review->communication_rating = $validated['communication_rating'];
        $review->check_in_rating = $validated['check_in_rating'];
        $review->accuracy_rating = $validated['accuracy_rating'];
        $review->location_rating = $validated['location_rating'];
        $review->value_rating = $validated['value_rating'];
        $review->comment = $validated['comment'];
        $review->is_published = true;
        $review->save();

        // Update the property's average rating
        $this->updatePropertyRating($booking->property_id);

        return redirect()->route('tenant.reviews.index')
            ->with('success', 'Your review has been submitted successfully.');
    }

    public function show(Review $review)
    {
        // Check if the review belongs to the tenant
        if ($review->user_id !== Auth::id()) {
            abort(403, 'Unauthorized action.');
        }

        $review->load(['property', 'booking']);

        return view('tenant.reviews.show', compact('review'));
    }

    public function edit(Review $review)
    {
        // Check if the review belongs to the tenant
        if ($review->user_id !== Auth::id()) {
            abort(403, 'Unauthorized action.');
        }

        $review->load(['property', 'booking']);

        return view('tenant.reviews.edit', compact('review'));
    }

    public function update(Request $request, Review $review)
    {
        // Check if the review belongs to the tenant
        if ($review->user_id !== Auth::id()) {
            abort(403, 'Unauthorized action.');
        }

        // Validate the request
        $validated = $request->validate([
            'cleanliness_rating' => 'required|integer|min:1|max:5',
            'communication_rating' => 'required|integer|min:1|max:5',
            'check_in_rating' => 'required|integer|min:1|max:5',
            'accuracy_rating' => 'required|integer|min:1|max:5',
            'location_rating' => 'required|integer|min:1|max:5',
            'value_rating' => 'required|integer|min:1|max:5',
            'comment' => 'required|string|min:10|max:1000',
        ]);

        // Calculate the overall rating (average of all ratings)
        $overallRating = round(
            ($validated['cleanliness_rating'] +
            $validated['communication_rating'] +
            $validated['check_in_rating'] +
            $validated['accuracy_rating'] +
            $validated['location_rating'] +
            $validated['value_rating']) / 6,
            1
        );

        // Update the review
        $review->rating = $overallRating;
        $review->cleanliness_rating = $validated['cleanliness_rating'];
        $review->communication_rating = $validated['communication_rating'];
        $review->check_in_rating = $validated['check_in_rating'];
        $review->accuracy_rating = $validated['accuracy_rating'];
        $review->location_rating = $validated['location_rating'];
        $review->value_rating = $validated['value_rating'];
        $review->comment = $validated['comment'];
        $review->save();

        // Update the property's average rating
        $this->updatePropertyRating($review->property_id);

        return redirect()->route('tenant.reviews.show', $review->id)
            ->with('success', 'Your review has been updated successfully.');
    }

    public function destroy(Review $review)
    {
        // Check if the review belongs to the tenant
        if ($review->user_id !== Auth::id()) {
            abort(403, 'Unauthorized action.');
        }

        $propertyId = $review->property_id;

        // Delete the review
        $review->delete();

        // Update the property's average rating
        $this->updatePropertyRating($propertyId);

        return redirect()->route('tenant.reviews.index')
            ->with('success', 'Your review has been deleted successfully.');
    }

    private function updatePropertyRating($propertyId)
    {
        $property = Property::findOrFail($propertyId);

        // Get all published reviews for the property
        $reviews = Review::where('property_id', $propertyId)
            ->where('is_published', true)
            ->get();

        if ($reviews->count() > 0) {
            // Calculate the average rating
            $averageRating = $reviews->avg('rating');

            // Update the property's rating
            $property->rating = round($averageRating, 1);
            $property->reviews_count = $reviews->count();
            $property->save();
        } else {
            // No reviews, reset the rating
            $property->rating = null;
            $property->reviews_count = 0;
            $property->save();
        }
    }
}
