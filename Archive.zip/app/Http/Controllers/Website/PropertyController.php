<?php

namespace App\Http\Controllers\Website;

use App\Http\Controllers\Controller;
use App\Models\Property;
use App\Models\PropertyType;
use App\Models\Amenity;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class PropertyController extends Controller
{
    public function index(Request $request)
    {
        $query = Property::with(['propertyType', 'images', 'amenities', 'user'])
            ->where('status', 'approved')
            ->withCount('reviews')
            ->withAvg('reviews', 'rating');

        // Filter by location
        if ($request->filled('location')) {
            $location = $request->location;
            $query->where(function($q) use ($location) {
                $q->where('city', 'like', "%{$location}%")
                  ->orWhere('state', 'like', "%{$location}%")
                  ->orWhere('address', 'like', "%{$location}%")
                  ->orWhere('zip_code', 'like', "%{$location}%");
            });
        }

        // Filter by property type
        if ($request->filled('property_type')) {
            $query->where('property_type_id', $request->property_type);
        }

        // Filter by price range
        if ($request->filled('price_range')) {
            $priceRange = explode('-', $request->price_range);
            if (count($priceRange) == 2) {
                $query->whereBetween('price', [$priceRange[0], $priceRange[1]]);
            } elseif (str_ends_with($request->price_range, '+')) {
                $minPrice = (int) str_replace('+', '', $request->price_range);
                $query->where('price', '>=', $minPrice);
            }
        }

        // Filter by bedrooms
        if ($request->filled('bedrooms')) {
            $query->where('bedrooms', '>=', $request->bedrooms);
        }

        // Filter by bathrooms
        if ($request->filled('bathrooms')) {
            $query->where('bathrooms', '>=', $request->bathrooms);
        }

        // Filter by amenities
        if ($request->filled('amenities')) {
            $amenities = $request->amenities;
            foreach ($amenities as $amenityId) {
                $query->whereHas('amenities', function($q) use ($amenityId) {
                    $q->where('amenities.id', $amenityId);
                });
            }
        }

        // Filter by availability
        if ($request->filled('availability')) {
            $availability = $request->availability;
            $today = now()->format('Y-m-d');

            if ($availability == 'immediate') {
                $query->where('available_from', '<=', $today);
            } elseif ($availability == 'within_week') {
                $nextWeek = now()->addWeek()->format('Y-m-d');
                $query->whereBetween('available_from', [$today, $nextWeek]);
            } elseif ($availability == 'within_month') {
                $nextMonth = now()->addMonth()->format('Y-m-d');
                $query->whereBetween('available_from', [$today, $nextMonth]);
            }
        }

        // Sort results
        if ($request->filled('sort')) {
            switch ($request->sort) {
                case 'price_low':
                    $query->orderBy('price', 'asc');
                    break;
                case 'price_high':
                    $query->orderBy('price', 'desc');
                    break;
                case 'rating':
                    $query->orderBy('reviews_avg_rating', 'desc');
                    break;
                case 'newest':
                default:
                    $query->orderBy('created_at', 'desc');
                    break;
            }
        } else {
            $query->orderBy('created_at', 'desc');
        }

        $properties = $query->paginate(9);
        $propertyTypes = PropertyType::all();
        $amenities = Amenity::all();

        return view('website.landing.rooms', compact('properties', 'propertyTypes', 'amenities'));
    }

    public function show(Property $property)
    {
        // Check if property is approved
        if ($property->status !== 'approved') {
            abort(404);
        }

        $property->load(['propertyType', 'images', 'amenities', 'user', 'reviews.user']);

        // Get similar properties
        $similarProperties = Property::with(['propertyType', 'images'])
            ->where('id', '!=', $property->id)
            ->where('status', 'approved')
            ->where(function($query) use ($property) {
                $query->where('property_type_id', $property->property_type_id)
                      ->orWhere('city', $property->city);
            })
            ->withCount('reviews')
            ->withAvg('reviews', 'rating')
            ->limit(3)
            ->get();

        // Check if property is available for booking
        $isAvailable = true;
        $unavailableDates = [];

        if ($property->bookings()->where('status', 'approved')->exists()) {
            $bookedDates = $property->bookings()
                ->where('status', 'approved')
                // ->select('check_in', 'check_out')
                ->get();

            foreach ($bookedDates as $booking) {
                $start = \Carbon\Carbon::parse($booking->check_in);
                $end = \Carbon\Carbon::parse($booking->check_out);

                for ($date = $start; $date->lte($end); $date->addDay()) {
                    $unavailableDates[] = $date->format('Y-m-d');
                }
            }

            $isAvailable = !in_array(now()->format('Y-m-d'), $unavailableDates);
        }

        return view('website.property-details', compact('property', 'similarProperties', 'isAvailable', 'unavailableDates'));
    }
}
