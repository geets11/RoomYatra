<?php

namespace App\Http\Controllers\Website;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PathController extends Controller
{
    public function home()
    {
        return view('website.landing.home');
    }

    public function rooms(){
        return view('website.landing.rooms');
    }

    public function howitworks(){
        return view('website.landing.how-it-works');
    }

    public function contact(){
        return view('website.landing.contact');
    }


}
